export interface Book {
  id: string;
  title: string;
  author: string;
  isbn: string;
  genre: string;
  publishedYear: number;
  description: string;
  coverImage: string;
  totalCopies: number;
  availableCopies: number;
  rating: number;
  tags: string[];
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'patron' | 'librarian' | 'admin';
  joinDate: string;
  borrowedBooks: BorrowedBook[];
  reservedBooks: string[];
  fines: number;
  isActive: boolean;
}

export interface BorrowedBook {
  bookId: string;
  book: Book;
  borrowDate: string;
  dueDate: string;
  returnDate?: string;
  isOverdue: boolean;
}

export interface Reservation {
  id: string;
  bookId: string;
  userId: string;
  reservationDate: string;
  status: 'pending' | 'ready' | 'fulfilled' | 'cancelled';
}

export interface LibraryStats {
  totalBooks: number;
  totalUsers: number;
  booksCheckedOut: number;
  overdueBooks: number;
  popularBooks: Book[];
  recentActivities: Activity[];
}

export interface Activity {
  id: string;
  type: 'borrow' | 'return' | 'reserve' | 'register';
  userId: string;
  bookId?: string;
  timestamp: string;
  description: string;
}

export interface SearchFilters {
  query: string;
  genre: string;
  author: string;
  availability: 'all' | 'available' | 'borrowed';
  sortBy: 'title' | 'author' | 'rating' | 'publishedYear';
  sortOrder: 'asc' | 'desc';
}