import React from 'react';
import { Book, Star, Calendar, Tag } from 'lucide-react';
import { Book as BookType } from '../../types';

interface BookCardProps {
  book: BookType;
  onBorrow?: (bookId: string) => void;
  onViewDetails?: (bookId: string) => void;
  showActions?: boolean;
}

const BookCard: React.FC<BookCardProps> = ({ 
  book, 
  onBorrow, 
  onViewDetails, 
  showActions = true 
}) => {
  const isAvailable = book.availableCopies > 0;

  return (
    <div className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow duration-200 overflow-hidden">
      <div className="aspect-w-3 aspect-h-4">
        <img
          src={book.coverImage}
          alt={book.title}
          className="w-full h-48 object-cover"
        />
      </div>
      
      <div className="p-4">
        <div className="flex items-start justify-between mb-2">
          <h3 className="text-lg font-semibold text-gray-900 line-clamp-2">
            {book.title}
          </h3>
          <div className="flex items-center space-x-1 text-yellow-500">
            <Star className="h-4 w-4 fill-current" />
            <span className="text-sm font-medium">{book.rating}</span>
          </div>
        </div>
        
        <p className="text-sm text-gray-600 mb-2">{book.author}</p>
        
        <div className="flex items-center space-x-4 text-xs text-gray-500 mb-3">
          <div className="flex items-center space-x-1">
            <Calendar className="h-3 w-3" />
            <span>{book.publishedYear}</span>
          </div>
          <div className="flex items-center space-x-1">
            <Tag className="h-3 w-3" />
            <span>{book.genre}</span>
          </div>
        </div>
        
        <p className="text-sm text-gray-700 line-clamp-3 mb-4">
          {book.description}
        </p>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
              isAvailable 
                ? 'bg-green-100 text-green-800' 
                : 'bg-red-100 text-red-800'
            }`}>
              {isAvailable ? 'Available' : 'Borrowed'}
            </span>
            <span className="text-xs text-gray-500">
              {book.availableCopies}/{book.totalCopies} copies
            </span>
          </div>
          
          {showActions && (
            <div className="flex space-x-2">
              <button
                onClick={() => onViewDetails?.(book.id)}
                className="text-blue-600 hover:text-blue-800 text-sm font-medium"
              >
                Details
              </button>
              {isAvailable && (
                <button
                  onClick={() => onBorrow?.(book.id)}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded text-sm font-medium transition-colors"
                >
                  Borrow
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BookCard;