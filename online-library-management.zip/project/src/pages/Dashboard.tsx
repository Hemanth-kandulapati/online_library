import React from 'react';
import { BookOpen, Users, TrendingUp, AlertCircle } from 'lucide-react';
import StatsCard from '../components/Dashboard/StatsCard';
import BookCard from '../components/Books/BookCard';
import { useLibrary } from '../contexts/LibraryContext';
import { getLibraryStats } from '../services/mockData';

const Dashboard: React.FC = () => {
  const { books } = useLibrary();
  const stats = getLibraryStats();

  const recentBooks = books.slice(0, 4);

  return (
    <div className="p-6 space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard
          title="Total Books"
          value={stats.totalBooks}
          icon={BookOpen}
          color="blue"
          trend={{ value: 12, isPositive: true }}
        />
        <StatsCard
          title="Active Users"
          value={stats.totalUsers}
          icon={Users}
          color="green"
          trend={{ value: 8, isPositive: true }}
        />
        <StatsCard
          title="Books Checked Out"
          value={stats.booksCheckedOut}
          icon={TrendingUp}
          color="yellow"
          trend={{ value: 3, isPositive: false }}
        />
        <StatsCard
          title="Overdue Books"
          value={stats.overdueBooks}
          icon={AlertCircle}
          color="red"
          trend={{ value: 15, isPositive: false }}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Activity</h3>
          <div className="space-y-4">
            {stats.recentActivities.map((activity) => (
              <div key={activity.id} className="flex items-center space-x-4">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <div>
                  <p className="text-sm text-gray-900">{activity.description}</p>
                  <p className="text-xs text-gray-500">
                    {new Date(activity.timestamp).toLocaleDateString()}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Popular Books</h3>
          <div className="space-y-4">
            {stats.popularBooks.slice(0, 5).map((book) => (
              <div key={book.id} className="flex items-center space-x-4">
                <img
                  src={book.coverImage}
                  alt={book.title}
                  className="w-12 h-16 object-cover rounded"
                />
                <div className="flex-1">
                  <h4 className="text-sm font-medium text-gray-900">{book.title}</h4>
                  <p className="text-xs text-gray-500">{book.author}</p>
                  <div className="flex items-center space-x-2 mt-1">
                    <span className="text-xs text-yellow-500">★ {book.rating}</span>
                    <span className="text-xs text-gray-500">
                      {book.totalCopies - book.availableCopies} borrowed
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-md">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Recently Added Books</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {recentBooks.map((book) => (
            <BookCard
              key={book.id}
              book={book}
              showActions={false}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;