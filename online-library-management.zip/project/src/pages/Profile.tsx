import React, { useState } from 'react';
import { User, Mail, Calendar, CreditCard, BookOpen, Clock } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const Profile: React.FC = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'profile' | 'borrowed' | 'history'>('profile');

  if (!user) return null;

  const mockBorrowedBooks = [
    {
      id: '1',
      title: 'The Great Gatsby',
      author: 'F. Scott Fitzgerald',
      dueDate: '2024-02-15',
      isOverdue: false
    },
    {
      id: '2',
      title: 'To Kill a Mockingbird',
      author: 'Harper Lee',
      dueDate: '2024-01-10',
      isOverdue: true
    }
  ];

  const mockHistory = [
    {
      id: '1',
      title: 'Pride and Prejudice',
      author: 'Jane Austen',
      borrowDate: '2023-12-01',
      returnDate: '2023-12-20'
    },
    {
      id: '2',
      title: 'Dune',
      author: 'Frank Herbert',
      borrowDate: '2023-11-15',
      returnDate: '2023-12-05'
    }
  ];

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="bg-gradient-to-r from-blue-500 to-blue-600 px-6 py-8">
          <div className="flex items-center space-x-4">
            <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center">
              <User className="h-10 w-10 text-blue-600" />
            </div>
            <div className="text-white">
              <h1 className="text-2xl font-bold">{user.name}</h1>
              <p className="text-blue-100 capitalize">{user.role}</p>
              <p className="text-blue-100 text-sm">Member since {new Date(user.joinDate).getFullYear()}</p>
            </div>
          </div>
        </div>

        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            {[
              { id: 'profile', label: 'Profile', icon: User },
              { id: 'borrowed', label: 'Borrowed Books', icon: BookOpen },
              { id: 'history', label: 'History', icon: Clock }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center space-x-2 py-4 border-b-2 transition-colors ${
                  activeTab === tab.id
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                <tab.icon className="h-5 w-5" />
                <span className="font-medium">{tab.label}</span>
              </button>
            ))}
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'profile' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-gray-900">Personal Information</h3>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-3">
                      <Mail className="h-5 w-5 text-gray-400" />
                      <span className="text-gray-700">{user.email}</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <Calendar className="h-5 w-5 text-gray-400" />
                      <span className="text-gray-700">Joined {new Date(user.joinDate).toLocaleDateString()}</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <CreditCard className="h-5 w-5 text-gray-400" />
                      <span className="text-gray-700">Outstanding Fines: ${user.fines}</span>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-gray-900">Account Statistics</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <p className="text-2xl font-bold text-blue-600">{mockBorrowedBooks.length}</p>
                      <p className="text-sm text-gray-600">Books Borrowed</p>
                    </div>
                    <div className="bg-green-50 p-4 rounded-lg">
                      <p className="text-2xl font-bold text-green-600">{mockHistory.length}</p>
                      <p className="text-sm text-gray-600">Books Read</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'borrowed' && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-gray-900">Currently Borrowed Books</h3>
              {mockBorrowedBooks.length === 0 ? (
                <p className="text-gray-500">No books currently borrowed.</p>
              ) : (
                <div className="space-y-3">
                  {mockBorrowedBooks.map((book) => (
                    <div key={book.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                      <div>
                        <h4 className="font-medium text-gray-900">{book.title}</h4>
                        <p className="text-sm text-gray-600">{book.author}</p>
                      </div>
                      <div className="text-right">
                        <p className={`text-sm font-medium ${
                          book.isOverdue ? 'text-red-600' : 'text-gray-600'
                        }`}>
                          Due: {new Date(book.dueDate).toLocaleDateString()}
                        </p>
                        {book.isOverdue && (
                          <p className="text-xs text-red-600">Overdue</p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'history' && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-gray-900">Reading History</h3>
              {mockHistory.length === 0 ? (
                <p className="text-gray-500">No reading history available.</p>
              ) : (
                <div className="space-y-3">
                  {mockHistory.map((book) => (
                    <div key={book.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                      <div>
                        <h4 className="font-medium text-gray-900">{book.title}</h4>
                        <p className="text-sm text-gray-600">{book.author}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-gray-600">
                          {new Date(book.borrowDate).toLocaleDateString()} - {new Date(book.returnDate).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Profile;