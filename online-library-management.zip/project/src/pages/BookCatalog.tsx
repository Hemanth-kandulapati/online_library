import React from 'react';
import BookCard from '../components/Books/BookCard';
import BookFilters from '../components/Books/BookFilters';
import { useLibrary } from '../contexts/LibraryContext';
import { useAuth } from '../contexts/AuthContext';

const BookCatalog: React.FC = () => {
  const { searchFilters, setSearchFilters, getFilteredBooks, borrowBook } = useLibrary();
  const { user } = useAuth();
  const filteredBooks = getFilteredBooks();

  const handleBorrowBook = async (bookId: string) => {
    if (user) {
      const success = await borrowBook(bookId, user.id);
      if (success) {
        alert('Book borrowed successfully!');
      } else {
        alert('Failed to borrow book. Please try again.');
      }
    }
  };

  const handleViewDetails = (bookId: string) => {
    // In a real app, this would navigate to a book details page
    console.log('View details for book:', bookId);
  };

  return (
    <div className="p-6">
      <BookFilters
        filters={searchFilters}
        onFiltersChange={setSearchFilters}
      />
      
      <div className="mb-4 flex items-center justify-between">
        <p className="text-sm text-gray-600">
          Showing {filteredBooks.length} books
        </p>
      </div>
      
      {filteredBooks.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-gray-500">No books found matching your criteria.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredBooks.map((book) => (
            <BookCard
              key={book.id}
              book={book}
              onBorrow={handleBorrowBook}
              onViewDetails={handleViewDetails}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default BookCatalog;