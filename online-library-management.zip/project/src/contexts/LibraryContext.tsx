import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Book, BorrowedBook, SearchFilters } from '../types';
import { mockBooks } from '../services/mockData';

interface LibraryContextType {
  books: Book[];
  searchFilters: SearchFilters;
  setSearchFilters: (filters: SearchFilters) => void;
  borrowBook: (bookId: string, userId: string) => Promise<boolean>;
  returnBook: (bookId: string, userId: string) => Promise<boolean>;
  addBook: (book: Omit<Book, 'id'>) => Promise<boolean>;
  updateBook: (bookId: string, updates: Partial<Book>) => Promise<boolean>;
  deleteBook: (bookId: string) => Promise<boolean>;
  getFilteredBooks: () => Book[];
}

const LibraryContext = createContext<LibraryContextType | undefined>(undefined);

export const useLibrary = () => {
  const context = useContext(LibraryContext);
  if (context === undefined) {
    throw new Error('useLibrary must be used within a LibraryProvider');
  }
  return context;
};

interface LibraryProviderProps {
  children: ReactNode;
}

export const LibraryProvider: React.FC<LibraryProviderProps> = ({ children }) => {
  const [books, setBooks] = useState<Book[]>(mockBooks);
  const [searchFilters, setSearchFilters] = useState<SearchFilters>({
    query: '',
    genre: '',
    author: '',
    availability: 'all',
    sortBy: 'title',
    sortOrder: 'asc'
  });

  const borrowBook = async (bookId: string, userId: string): Promise<boolean> => {
    const book = books.find(b => b.id === bookId);
    if (book && book.availableCopies > 0) {
      setBooks(prevBooks => 
        prevBooks.map(b => 
          b.id === bookId 
            ? { ...b, availableCopies: b.availableCopies - 1 }
            : b
        )
      );
      return true;
    }
    return false;
  };

  const returnBook = async (bookId: string, userId: string): Promise<boolean> => {
    const book = books.find(b => b.id === bookId);
    if (book) {
      setBooks(prevBooks => 
        prevBooks.map(b => 
          b.id === bookId 
            ? { ...b, availableCopies: b.availableCopies + 1 }
            : b
        )
      );
      return true;
    }
    return false;
  };

  const addBook = async (book: Omit<Book, 'id'>): Promise<boolean> => {
    const newBook: Book = {
      ...book,
      id: Date.now().toString()
    };
    setBooks(prevBooks => [...prevBooks, newBook]);
    return true;
  };

  const updateBook = async (bookId: string, updates: Partial<Book>): Promise<boolean> => {
    setBooks(prevBooks => 
      prevBooks.map(book => 
        book.id === bookId ? { ...book, ...updates } : book
      )
    );
    return true;
  };

  const deleteBook = async (bookId: string): Promise<boolean> => {
    setBooks(prevBooks => prevBooks.filter(book => book.id !== bookId));
    return true;
  };

  const getFilteredBooks = (): Book[] => {
    let filtered = [...books];

    // Apply search query
    if (searchFilters.query) {
      const query = searchFilters.query.toLowerCase();
      filtered = filtered.filter(book => 
        book.title.toLowerCase().includes(query) ||
        book.author.toLowerCase().includes(query) ||
        book.description.toLowerCase().includes(query) ||
        book.tags.some(tag => tag.toLowerCase().includes(query))
      );
    }

    // Apply genre filter
    if (searchFilters.genre) {
      filtered = filtered.filter(book => book.genre === searchFilters.genre);
    }

    // Apply author filter
    if (searchFilters.author) {
      filtered = filtered.filter(book => book.author === searchFilters.author);
    }

    // Apply availability filter
    if (searchFilters.availability !== 'all') {
      filtered = filtered.filter(book => 
        searchFilters.availability === 'available' 
          ? book.availableCopies > 0
          : book.availableCopies === 0
      );
    }

    // Apply sorting
    filtered.sort((a, b) => {
      const aValue = a[searchFilters.sortBy];
      const bValue = b[searchFilters.sortBy];
      
      if (searchFilters.sortOrder === 'asc') {
        return aValue < bValue ? -1 : aValue > bValue ? 1 : 0;
      } else {
        return aValue > bValue ? -1 : aValue < bValue ? 1 : 0;
      }
    });

    return filtered;
  };

  return (
    <LibraryContext.Provider value={{
      books,
      searchFilters,
      setSearchFilters,
      borrowBook,
      returnBook,
      addBook,
      updateBook,
      deleteBook,
      getFilteredBooks
    }}>
      {children}
    </LibraryContext.Provider>
  );
};