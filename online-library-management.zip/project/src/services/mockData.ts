import { Book, User, BorrowedBook, Activity, LibraryStats } from '../types';

export const mockBooks: Book[] = [
  {
    id: '1',
    title: 'The Great Gatsby',
    author: 'F. Scott Fitzgerald',
    isbn: '978-0-7432-7356-5',
    genre: 'Classic Literature',
    publishedYear: 1925,
    description: 'A masterpiece of American literature set in the summer of 1922, exploring themes of wealth, love, and the American Dream.',
    coverImage: 'https://images.pexels.com/photos/1029141/pexels-photo-1029141.jpeg?auto=compress&cs=tinysrgb&w=400',
    totalCopies: 5,
    availableCopies: 3,
    rating: 4.2,
    tags: ['Classic', 'American Literature', 'Romance']
  },
  {
    id: '2',
    title: 'To Kill a Mockingbird',
    author: 'Harper Lee',
    isbn: '978-0-06-112008-4',
    genre: 'Classic Literature',
    publishedYear: 1960,
    description: 'A gripping tale of racial injustice and childhood innocence in the American South.',
    coverImage: 'https://images.pexels.com/photos/1029141/pexels-photo-1029141.jpeg?auto=compress&cs=tinysrgb&w=400',
    totalCopies: 4,
    availableCopies: 2,
    rating: 4.5,
    tags: ['Classic', 'Social Justice', 'Coming of Age']
  },
  {
    id: '3',
    title: 'The Catcher in the Rye',
    author: 'J.D. Salinger',
    isbn: '978-0-316-76948-0',
    genre: 'Classic Literature',
    publishedYear: 1951,
    description: 'A controversial novel about teenage rebellion and alienation in post-war America.',
    coverImage: 'https://images.pexels.com/photos/1029141/pexels-photo-1029141.jpeg?auto=compress&cs=tinysrgb&w=400',
    totalCopies: 3,
    availableCopies: 1,
    rating: 3.8,
    tags: ['Classic', 'Coming of Age', 'Psychology']
  },
  {
    id: '4',
    title: 'Dune',
    author: 'Frank Herbert',
    isbn: '978-0-441-17271-9',
    genre: 'Science Fiction',
    publishedYear: 1965,
    description: 'An epic science fiction novel set in a distant future amidst a feudal interstellar society.',
    coverImage: 'https://images.pexels.com/photos/1029141/pexels-photo-1029141.jpeg?auto=compress&cs=tinysrgb&w=400',
    totalCopies: 6,
    availableCopies: 4,
    rating: 4.6,
    tags: ['Science Fiction', 'Epic', 'Adventure']
  },
  {
    id: '5',
    title: 'Pride and Prejudice',
    author: 'Jane Austen',
    isbn: '978-0-14-143951-8',
    genre: 'Romance',
    publishedYear: 1813,
    description: 'A romantic novel of manners set in Georgian England, exploring themes of marriage, money, and social expectations.',
    coverImage: 'https://images.pexels.com/photos/1029141/pexels-photo-1029141.jpeg?auto=compress&cs=tinysrgb&w=400',
    totalCopies: 4,
    availableCopies: 3,
    rating: 4.3,
    tags: ['Romance', 'Classic', 'British Literature']
  },
  {
    id: '6',
    title: '1984',
    author: 'George Orwell',
    isbn: '978-0-452-28423-4',
    genre: 'Dystopian Fiction',
    publishedYear: 1949,
    description: 'A dystopian novel about totalitarianism and the dangers of government surveillance.',
    coverImage: 'https://images.pexels.com/photos/1029141/pexels-photo-1029141.jpeg?auto=compress&cs=tinysrgb&w=400',
    totalCopies: 5,
    availableCopies: 0,
    rating: 4.4,
    tags: ['Dystopian', 'Political', 'Classic']
  },
  {
    id: '7',
    title: 'The Lord of the Rings',
    author: 'J.R.R. Tolkien',
    isbn: '978-0-544-00341-5',
    genre: 'Fantasy',
    publishedYear: 1954,
    description: 'An epic high fantasy adventure about the quest to destroy the One Ring and defeat the Dark Lord Sauron.',
    coverImage: 'https://images.pexels.com/photos/1029141/pexels-photo-1029141.jpeg?auto=compress&cs=tinysrgb&w=400',
    totalCopies: 8,
    availableCopies: 5,
    rating: 4.7,
    tags: ['Fantasy', 'Epic', 'Adventure']
  },
  {
    id: '8',
    title: 'The Handmaid\'s Tale',
    author: 'Margaret Atwood',
    isbn: '978-0-385-49081-8',
    genre: 'Dystopian Fiction',
    publishedYear: 1985,
    description: 'A speculative fiction novel about a totalitarian society where women are subjugated.',
    coverImage: 'https://images.pexels.com/photos/1029141/pexels-photo-1029141.jpeg?auto=compress&cs=tinysrgb&w=400',
    totalCopies: 4,
    availableCopies: 2,
    rating: 4.1,
    tags: ['Dystopian', 'Feminist', 'Speculative Fiction']
  }
];

export const mockUsers: User[] = [
  {
    id: '1',
    name: 'Danny',
    email: 'danny@email.com',
    role: 'patron',
    joinDate: '2023-01-15',
    borrowedBooks: [],
    reservedBooks: [],
    fines: 0,
    isActive: true
  },
  {
    id: '2',
    name: 'Anil',
    email: 'anil@email.com',
    role: 'librarian',
    joinDate: '2022-03-10',
    borrowedBooks: [],
    reservedBooks: [],
    fines: 0,
    isActive: true
  },
  {
    id: '3',
    name: 'Sireesha',
    email: 'sireesha@email.com',
    role: 'admin',
    joinDate: '2021-01-01',
    borrowedBooks: [],
    reservedBooks: [],
    fines: 0,
    isActive: true
  },
  {
    id: '4',
    name: 'Samatha',
    email: 'samatha@email.com',
    role: 'patron',
    joinDate: '2023-06-20',
    borrowedBooks: [],
    reservedBooks: [],
    fines: 0,
    isActive: true
  }
];

export const getLibraryStats = (): LibraryStats => ({
  totalBooks: mockBooks.length,
  totalUsers: mockUsers.length,
  booksCheckedOut: mockBooks.reduce((total, book) => total + (book.totalCopies - book.availableCopies), 0),
  overdueBooks: 3,
  popularBooks: mockBooks.slice(0, 5),
  recentActivities: [
    {
      id: '1',
      type: 'borrow',
      userId: '1',
      bookId: '1',
      timestamp: '2024-01-15T10:30:00Z',
      description: 'Danny borrowed "The Great Gatsby"'
    },
    {
      id: '2',
      type: 'return',
      userId: '1',
      bookId: '2',
      timestamp: '2024-01-15T09:15:00Z',
      description: 'Danny returned "To Kill a Mockingbird"'
    }
  ]
});